// p = mat + 1; mat é um array de números inteiros que nessa expressão esta representando o endereço da posição 0 
// (já que esta somente o nome mat), e esta sendo incrementado em uma posição, ficando no final p = mat[1].

// x = (*mat); essa expressão quer dizer que x = mat[0], o que quer dizer que x recebe o primeiro elemento do vetor mat.