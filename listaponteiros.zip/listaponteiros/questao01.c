// 1 (true) 
// 3 - 5 = -2 
// 3
// 3 - 3/5 + 7 = 10 , devido as variáveis serem int e essa divisão resultar em 0.6, apenas a parte 
// inteira vai ser usada, que seria 0  