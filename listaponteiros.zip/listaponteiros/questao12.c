// O programa do jeito que esta escrito não terá saída por dois motivos: 
// 1 - Um valor inteiro não pode ser atribuído diretamente a um ponteiro.
// 2 - Dentro do printf esta acontecendo um incremento em um ponteiro que é constante, porém como é constante não pode sofrer alterações. 