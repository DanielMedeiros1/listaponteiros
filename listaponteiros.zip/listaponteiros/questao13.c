// Considerando que o endereço de memória de x[0] é 4092 
// char ocupa 1 byte, x+1 = 4093; x+2 = 4094; x+3 = 4095
// int ocupa 2 bytes, x+1 = 4094; x+2 = 4096; x+3 = 4098
// float ocupa 4 bytes, x+1 = 4096; x+2 = 4100; x+3 = 4104
// double ocupa 8 bytes, x+1 = 4100; x+2 = 4108; x+3 = 4116
