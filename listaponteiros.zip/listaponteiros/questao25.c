// A alternativa C é a que contém vazamento de memória, devido ao uso da função strlen, 
// que acaba procurando mais de 50 caracteres e com isso não permite que a memória seja 
// liberada pela função free() 
